/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javachatapplication2;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;

public class ChatAppPOEP3 {
    // Arrays stores user information
    static String[] userNames = new String[10];
    static String[] passWords = new String[10];
    static String[] phoneNumbers = new String[10];
    static String[] messages = new String[10]; // Array to store messages for each user logged in and registerd
    static int userCount = 2; // Assuming two pre-registered users

    // Main method to run the application
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Hello there and welcome to our Porsche ChatApp!");

        while (true) {
            System.out.println("Menu:");
            System.out.println();
            System.out.println("1. Register a User");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option (1-3): ");

            String choice = input.nextLine();

            if (choice.equals("1")) {
                register(input);
            } else if (choice.equals("2")) {
                login(input);
            } else if (choice.equals("3")) {
                System.out.println("Exiting program. Thank you!");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
        input.close();
    }//code guided by Ai(Claude)
    

    static void register(Scanner input) {
        if (userCount >= 10) {
            System.out.println("User limit reached! Cannot register more users.");
            return;
        }

        System.out.println("<<<Registration>>>");
        System.out.println();
        System.out.print("Enter your username (max of 5 characters and must include '_'): ");
        String username = input.nextLine();

        if (username.length() > 5 || !username.contains("_")) {
            System.out.println("Invalid username, please make sure it's 5 characters or less and includes '_'.");
            return;
        }

        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(username)) {
                System.out.println("This username already exists! Please choose a different username.");
                return;
            }
        }

        System.out.print("Enter your password (minimum of 8 characters, with an uppercase, a number, and a symbol): ");
        String password = input.nextLine();

        boolean hasUppercase = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSymbol = !password.matches("[A-Za-z0-9]*");

        if (password.length() < 8 || !hasUppercase || !hasNumber || !hasSymbol) {
            System.out.println("Invalid password! Must be at least 8 characters and include an uppercase letter, a number, and a symbol.");
            return;
        }//Code Guided by Ai(Claude)

        System.out.print("Enter your phone number (+27 followed by 9 digits): ");
        String phone = input.nextLine();

        // user is phone number validation if phone number is according to requrements
        if (!phone.matches("\\+27\\d{9}")) {
            System.out.println("Invalid phone number! Format should be like: +27123456789.");
            return;
        }

        userNames[userCount] = username;
        passWords[userCount] = password;
        phoneNumbers[userCount] = phone;
        messages[userCount] = ""; // Initialize empty message inbox
        userCount++;

        System.out.println("Registration successful! Welcome to our Porsche ChatApp.");
    }//Code guided by AI(CLaude)

    static void login(Scanner input) {
        System.out.println("<<<Login>>>");
        System.out.println();
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();

        int userIndex = -1;

        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(username)) {
                if (passWords[i].equals(password)) {
                    userIndex = i;
                    break;
                } else {
                    System.out.println("Login failed. Incorrect password.");
                    return;
                }
            }
        }// code Guided by Ai(Claude)
// If username is not found
        if (userIndex == -1) {
            System.out.println("Username is not found. Please register.");
            return;
        }

        System.out.println("Login successful!");
        System.out.println("Welcome back");
        System.out.println("Your messages:\n" + (messages[userIndex].isEmpty() ? "No messages yet." : messages[userIndex]));

        while (true) {
            System.out.println("Options:");
            System.out.println();
            System.out.println("1. Send Message");
            System.out.println("2. Logout");
            System.out.print("Choose an option: ");
            String choice = input.nextLine();

            if (choice.equals("1")) {
                sendMessage(input, userIndex);
            } else if (choice.equals("2")) {
                System.out.println("Logging out...");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
    }//Guided by Ai(claude)

    // Handle user input
    static void sendMessage(Scanner input, int senderIndex) {
        System.out.print("Enter the username of the recipient: ");
        String recipient = input.nextLine();
        int recipientIndex = -1;

        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(recipient)) {
                recipientIndex = i;
                break;
            }
        }

        if (recipientIndex == -1) {
            System.out.println("User is not found.");
            return;
        }

        System.out.print("Enter your message: ");
        String message = input.nextLine();
        messages[recipientIndex] += "\nMessage from " + userNames[senderIndex] + ": " + message;

        System.out.println("Message has been sent successfully!");
    }// class guidesd by Ai(claude)
}

