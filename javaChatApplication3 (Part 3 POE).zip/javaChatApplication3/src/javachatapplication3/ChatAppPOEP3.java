/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javachatapplication3;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.security.MessageDigest;
import java.util.UUID;
//Code has been giuded by Artificial Inteligince(Calude)

public class ChatAppPOEP3 {
    // User information stored in arrays
    static String[] userNames = new String[10];
    static String[] passWords = new String[10];
    static String[] phoneNumbers = new String[10];
    static String[] messages = new String[10];
    static int userCount = 2;
    //Ocde guided by Artificisl Inteligences(Claude)

    // Arrays for message storage as per Part 3 requirements
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static ArrayList<String> flags = new ArrayList<>();
    //Code has been giuded by Artificial Inteligince(Calude)

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("-----------------------------------------------------");
        System.out.println("Hello there and welcome to our Porsche ChatApp");
        System.out.println("-----------------------------------------------------");

        while (true) {
            System.out.println("Menu:");
            System.out.println();
            System.out.println("1. Register a user");
            System.out.println("2. Login");
            System.out.println("3. Display message reports");
            System.out.println("4. Exit");
            System.out.println("***************");
            System.out.print("Choose an option (1-4): ");

            String choice = input.nextLine();

            if (choice.equals("1")) {
                register(input);
            } else if (choice.equals("2")) {
                login(input);
            } else if (choice.equals("3")) {
                displayReports(input);
            } else if (choice.equals("4")) {
                System.out.println("Exiting program. Thank you!");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
        input.close();
    }//Code has been giuded by Artificial Inteligince(Calude)

    static void register(Scanner input) {
        if (userCount >= 10) {
            System.out.println("User limit reached! Cannot register more users.");
            return;
        }

        System.out.println("<<<Registration>>>");
        System.out.println("-----------------");
        System.out.println();
        System.out.print("Enter your username (max of 5 characters and must include '_'): ");
        String username = input.nextLine();

        if (username.length() > 5 || !username.contains("_")) {
            System.out.println("Invalid username input, please make sure it's 5 characters or less and includes '_'.");
            return;
        }//Code has been giuded by Artificial Inteligince(Calude)

        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(username)) {
                System.out.println("This username already exists, Please choose a different username.");
                return;
            }
        }

        System.out.print("Enter your password (minimum of 8 characters, with an uppercase, a number, and a symbol): ");
        String password = input.nextLine();

        boolean hasUppercase = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSymbol = !password.matches("[A-Za-z0-9]*");

        if (password.length() < 8 || !hasUppercase || !hasNumber || !hasSymbol) {
            System.out.println("Invalid password!  yuor password must be at least 8 characters and include an uppercase letter, a number, and a symbol.");
            return;
        }//Code has been giuded by Artificial Inteligince(Calude)

        System.out.print("Enter your phone number (+27 followed by 9 digits): ");
        String phone = input.nextLine();

        if (!phone.matches("\\+27\\d{9}")) {
            System.out.println("Invalid phone number! Format should be like: +27123456789.");
            return;
        }

        userNames[userCount] = username;
        passWords[userCount] = password;
        phoneNumbers[userCount] = phone;
        messages[userCount] = "";
        userCount++;

        System.out.println("Registration successful! Welcome to our Porsche ChatApp.");
    }//Code has been giuded by Artificial Inteligince(Calude)

    static void login(Scanner input) {
        System.out.println("<<<Login>>>");
        System.out.println("------------");
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();

        int userIndex = -1;

        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(username)) {
                if (passWords[i].equals(password)) {
                    userIndex = i;
                    break;
                } else {
                    System.out.println("Login failed. Incorrect password.");
                    return;
                }
            }
        }//Code has been giuded by Artificial Inteligince(Calude)

        if (userIndex == -1) {
            System.out.println("Username is not found. Please register.");
            return;
        }

        System.out.println("Login successful!");
        System.out.println();
        System.out.println("Welcome back: " + username);
        System.out.println("Your messages:\n" + (messages[userIndex].isEmpty() ? "No messages yet." : messages[userIndex]));

        while (true) {
            System.out.println("Options:");
            System.out.println("-------------");
            System.out.println();
            System.out.println("1. Send a message");
            System.out.println("2. View message reports");
            System.out.println("3. Logout");
            System.out.println("**************");
            System.out.print("Choose an option: ");
            String choice = input.nextLine();

            if (choice.equals("1")) {
                sendMessage(input, userIndex);
            } else if (choice.equals("2")) {
                displayUserReports(input);
            } else if (choice.equals("3")) {
                System.out.println("Logging out...");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
    }//Code has been giuded by Artificial Inteligince(Calude)

    static void sendMessage(Scanner input, int senderIndex) {
        System.out.print("\nEnter the username of the recipient: ");
        String recipient = input.nextLine();
        int recipientIndex = -1;

        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(recipient)) {
                recipientIndex = i;
                break;
            }
        }

        if (recipientIndex == -1) {
            System.out.println("Tjis user  is not found.");
            return;
        }

        System.out.print("Enter your message: ");
        String message = input.nextLine();
       
        // Generate ID and hash for the message
        String messageID = UUID.randomUUID().toString();
        String messageHash = generateHash(message);
       
        // Store message details in appropriate arrays
        sentMessages.add(message);
        messageHashes.add(messageHash);
        messageIDs.add(messageID);
        recipients.add(phoneNumbers[recipientIndex]);
        flags.add("Sent");
       
        messages[recipientIndex] += "\nMessage from " + userNames[senderIndex] + ": " + message;
        System.out.println("Message has been sent successfully!");
        System.out.println("Message ID: " + messageID);
    }

    static void displayReports(Scanner input) {
        System.out.println("<<<Message Reports>>>");
        System.out.println("--------------------");
        System.out.println();
        System.out.println("1. Display all sent messages");
        System.out.println("2. Display longest message");
        System.out.println("3. Search by message ID");
        System.out.println("4. Search messages by recipient");
        System.out.println("5. Delete message by hash");
        System.out.println("6. Display full report");
        System.out.println("****************");
        System.out.print("Choose an option (1-6): ");
       
        String choice = input.nextLine();
       
        switch(choice) {
            case "1":
                displayAllSentMessages();
                break;
            case "2":
                displayLongestMessage();
                break;
            case "3": 
                searchByMessageID(input);
                break;
            case "4":
                searchByRecipient(input);
                break;
            case "5":
                deleteByHash(input);
                break;
            case "6":
                displayFullReport();
                break;
            default:
                System.out.println("Thats an Invalid option.");
        }
    }//Code has been giuded by Artificial Inteligince(Calude)

    static void displayUserReports(Scanner input) {
        System.out.println("<<<Your Message Reports>>>");
        System.out.println("---------------");
        System.out.println();
        System.out.println("1. Display all your sent messages");
        System.out.println("2. Display your longest message");
        System.out.println("****************");
        System.out.print("Choose an option (1-2): ");
       
        String choice = input.nextLine();
       
        switch(choice) {
            case "1":
                displayUserSentMessages(input);
                break;
            case "2":
                displayUserLongestMessage(input);
                break;
            default:
                System.out.println("Invalid option.");
        }
    }//Code has been giuded by Artificial Inteligince(Calude)

    // Helper methods for report functionality
    static void displayAllSentMessages() {
        System.out.println("All Sent Messages:");
        System.out.println();
        for (int i = 0; i < sentMessages.size(); i++) {
            if (flags.get(i).equals("Sent")) {
                System.out.println("Recipient: " + recipients.get(i));
                System.out.println("Message: " + sentMessages.get(i));
                System.out.println("-------------------");
            }
        }
    }

    static void displayLongestMessage() {
        String longest = "";
        int index = -1;
       
        for (int i = 0; i < sentMessages.size(); i++) {
            if (flags.get(i).equals("Sent") && sentMessages.get(i).length() > longest.length()) {
                longest = sentMessages.get(i);
                index = i;
            }
        }//Code has been giuded by Artificial Inteligince(Calude)
       
        if (index != -1) {
            System.out.println("Teh longest Sent Message:");
            System.out.println();
            System.out.println("Recipient: " + recipients.get(index));
            System.out.println("Message: " + longest);
            System.out.println("Length: " + longest.length() + " characters");
        } else {
            System.out.println("No sent messages found.");
        }
    }//Code has been giuded by Artificial Inteligince(Calude)

    static void searchByMessageID(Scanner input) {
        System.out.print("Enter message ID to search: ");
        System.out.println();
        String id = input.nextLine();
       
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                System.out.println("Message found:");
                System.out.println("Recipient: " + recipients.get(i));
                System.out.println("Message: " + sentMessages.get(i));
                return;
            }
        }
        System.out.println("Message with ID " + id + " not found.");
    }

    static void searchByRecipient(Scanner input) {
        System.out.print("Enter the recipients phone number to search: ");
        System.out.println();
        String phone = input.nextLine();
       
        System.out.println("Messages sent to " + phone + ":");
        boolean found = false;
       
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(phone)) {
                System.out.println("Message: " + sentMessages.get(i));
                System.out.println("Status: " + flags.get(i));
                System.out.println("-------------------");
                found = true;
            }
        }
       
        if (!found) {
            System.out.println("No messages found for recipient " + phone);
        }
    }

    static void deleteByHash(Scanner input) {
        System.out.print("Enter message hash to delete: ");
        System.out.println();
        String hash = input.nextLine();
       
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                System.out.println("Deleting message: " + sentMessages.get(i));
                sentMessages.remove(i);
                messageHashes.remove(i);
                messageIDs.remove(i);
                recipients.remove(i);
                flags.remove(i);
                System.out.println("Message successfully deleted.");
                return;
            }
        }
        System.out.println("Message with hash " + hash + " not found.");
    }

    static void displayFullReport() {
        System.out.println("Full Message Report:");
        System.out.println();
        System.out.printf("%-20s %-15s %-50s %-10s\n", "Message ID", "Recipient", "Message", "Status");
        System.out.println("----------------------------------------------------------------------------------");
       
        for (int i = 0; i < sentMessages.size(); i++) {
            System.out.printf("%-20s %-15s %-50s %-10s\n",
                messageIDs.get(i),
                recipients.get(i),
                sentMessages.get(i).length() > 45 ? sentMessages.get(i).substring(0, 45) + "..." : sentMessages.get(i),
                flags.get(i));
        }
    }//Code giuded by Artificial Inteligince(Calude)

    static void displayUserSentMessages(Scanner input) {
        System.out.println("Your Sent Messages:");
        System.out.println();
        // This would see which messages were sent by which user
        //Not implemented as the original code doesn't track sender
        System.out.println("Feature not fully implemented yet.");
    }

    static void displayUserLongestMessage(Scanner input) {
        System.out.println("Your Longest Message:");
        System.out.println();
        // Similar to above, would need sender tracking
        System.out.println("Feature not fully implemented yet.");
    }//Code has been giuded by Artificial Inteligince(Calude)

    // the method to generate message hash
    static String generateHash(String message) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(message.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
           
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
           
            return hexString.toString();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }//Code has been giuded by Artificial Inteligince(Calude)

    // Method to populate with test data
    static void populateTestData() {
        // Test Data Message 1
        sentMessages.add("Did you get the cake?");
        recipients.add("+27834557896");
        flags.add("Sent");
        messageIDs.add(UUID.randomUUID().toString());
        messageHashes.add(generateHash("Did you get the cake?"));
        //Code giuded by Artificial Inteligince(Calude)
       
        // Test Data Message 2
        sentMessages.add("Where are you? You are late! I have asked you to be on time.");
        recipients.add("+27838884567");
        flags.add("Stored");
        messageIDs.add(UUID.randomUUID().toString());
        messageHashes.add(generateHash("Where are you? You are late! I have asked you to be on time."));
        //Code giuded by Artificial Inteligince(Calude)
       
        // Test Data Message 3
        sentMessages.add("Yohoooo, I am at your gate.");
        recipients.add("+27834484567");
        flags.add("Disregard");
        messageIDs.add(UUID.randomUUID().toString());
        messageHashes.add(generateHash("Yohoooo, I am at your gate."));
       //Code giuded by Artificial Inteligince(Calude)
        
        // Test Data Message 4
        sentMessages.add("It is dinner time !");
        recipients.add("0838884567");
        flags.add("Sent");
        messageIDs.add(UUID.randomUUID().toString());
        messageHashes.add(generateHash("It is dinner time !"));
        //Code giuded by Artificial Inteligince(Calude)
       
        // Test Data Message 5
        sentMessages.add("Ok, I am leaving without you.");
        recipients.add("+27838884567");
        flags.add("Stored");
        messageIDs.add(UUID.randomUUID().toString());
        messageHashes.add(generateHash("Ok, I am leaving without you."));
        //Code giuded by Artificial Inteligince(Calude)
    }
}
