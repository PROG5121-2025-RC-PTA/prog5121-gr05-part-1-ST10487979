import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
// Main class that runs this application
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Series seriesApp = new Series();
        
        System.out.println("*****************************************************");
        System.out.println("Welcome to DSTV Channel seacher");
        System.out.println("Lates Series- 2025");
        System.out.println("*****************************************************");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        System.out.println();
        System.out.println("******************************************************");
        String input = scanner.nextLine();
        
        if (!input.equals("1")) {
            System.out.println("Exiting application. Goodbye!");
            scanner.close();
            return;
        }
        
        seriesApp.displayMenu();//Code guided by Artificial Inteligence
        
        while (true) {
            System.out.print("Please enter your choice: ");
            System.out.println();
            String choice = scanner.nextLine();
            
            switch (choice) {
                case "1":
                    seriesApp.CaptureSeries();
                    break;
                case "2":
                    seriesApp.SearchSeries();
                    break;
                case "3":
                    seriesApp.UpdateSeries();
                    break;
                case "4":
                    seriesApp.DeleteSeries();
                    break;
                case "5":
                    seriesApp.SeriesReport();
                    break;
                case "6":
                    seriesApp.ExitSeriesApplication();
                    break;
                default:
                    System.out.println("Thats an invalid choice. Please try again.");
                    seriesApp.displayMenu();
            } //Code guided by Artificial Inteligence
        }
    }
}

