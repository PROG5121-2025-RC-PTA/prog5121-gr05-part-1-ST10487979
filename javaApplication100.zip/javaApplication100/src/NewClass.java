/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
import java.util.ArrayList;
import java.util.Scanner;

// SeriesModel class as specified in the requirements
class SeriesModel {
    public String SeriesId;
    public String SeriesName;
    public String SeriesAge;
    public String SeriesNumberOfEpisodes;
    
    // Constructor for easier object creation
    public SeriesModel(String id, String name, String age, String episodes) {
        this.SeriesId = id;
        this.SeriesName = name;
        this.SeriesAge = age;
        this.SeriesNumberOfEpisodes = episodes;
    }
}

// Main Series class with all required methods
class Series {
    private ArrayList<SeriesModel> seriesList;
    private Scanner scanner;
    
    public Series() {
        seriesList = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    
    // Method to display the main menu
    public void displayMenu() {
        System.out.println("Latest Channel - 2025");
        System.out.println("*****************************************************");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1)Capture a new series.");
        System.out.println("(2)Search for a series.");
        System.out.println("(3)Update Book");
        System.out.println("(4)Delete Book.");
        System.out.println("(5)View Report");
        System.out.println("(6)Exit.");
    }
    
    // Method to capture a new series
    public void CaptureSeries() {
        System.out.println("******************************");
        System.out.println("Capture A New Channel");
        
       
        System.out.print("Enter the series id: ");
        String id = scanner.nextLine();
        
        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();
        
        String age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            age = scanner.nextLine();
            
            // Validates age restriction
            if (!isNumeric(age)) {
                System.out.println("You have entered an incorrect series age!!!");
                System.out.print("Please re-enter the series age >> ");
                continue;//Code guided by Artificial Inteligence
            }
            
            int ageValue = Integer.parseInt(age);
            if (ageValue < 2 || ageValue > 18) {
                System.out.println("You have entered an age restricted age!!!");
                System.out.print("Please re-enter the channel age >> ");
            } else {
                break;
            }//Code guided by Artificial Inteligence
        }
        
        System.out.print("Enter the number of episodes for " + name + ": ");
        String episodes = scanner.nextLine();
        
        // Create and add the new series
        SeriesModel newSeries = new SeriesModel(id, name, age, episodes);
        seriesList.add(newSeries);
        
        System.out.println("Series processed successfully!!!");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String input = scanner.nextLine();
        if (input.equals("1")) {
            displayMenu();
        }//Code guided by Artificial Inteligence
    }
    
    // Method to search for a series
    public void SearchSeries() {
        System.out.println("*******************************");
        System.out.print("Enter the channel id to search: ");
        System.out.println();
        System.out.println("********************************");
        System.out.println();
        String id = scanner.nextLine();
        
        boolean found = false;
        for (SeriesModel series : seriesList) {
            if (series.SeriesId.equals(id)) {
                System.out.println("-----------------------------------------------------");
                System.out.println("Channel ID: " + series.SeriesId);
                System.out.println("Channel Name: " + series.SeriesName);
                System.out.println("Chanel Age Restrictions: " + series.SeriesAge);
                System.out.println("Number Of Channel Episodes: " + series.SeriesNumberOfEpisodes);
                System.out.println("-----------------------------------------------------");
                found = true;
                break;
            }//Code guided by Artificial Inteligence
        }
        
        if (!found) {
            System.out.println("---");
            System.out.println("Series with Series Id: " + id + " was not found!");
            System.out.println("---");
        }
        
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String input = scanner.nextLine();
        if (input.equals("1")) {
            displayMenu();
        }//Code guided by Artificial Inteligence
    }
    
    // Method to update a series
    public void UpdateSeries() {
        System.out.println("*******************************");
        System.out.print("Enter the series id to update: ");
        System.out.println();
        System.out.println("*******************************");
        System.out.println();
        String id = scanner.nextLine();
        
        boolean found = false;
        for (SeriesModel series : seriesList) {
            if (series.SeriesId.equals(id)) {
                System.out.print("Enter the series name: ");
                series.SeriesName = scanner.nextLine();
                
                String age;
                while (true) {
                    System.out.print("Enter the age restriction: ");
                    age = scanner.nextLine();
                    
                    // This validates age restriction(If a certain age qualifies to log in the system
                    if (!isNumeric(age)) {
                        System.out.println("You have entered a incorrect series age!!!");
                        System.out.print("Please re-enter the series age== ");
                        continue;
                    }
                    
                    int ageValue = Integer.parseInt(age);
                    if (ageValue < 2 || ageValue > 18) {
                        System.out.println("You have entered an incorrect series age!!!");
                        System.out.print("Please re-enter the series age== ");
                    } else {
                        series.SeriesAge = age;
                        break;
                    }
                }//Code guided by Artificial Inteligence
                
                System.out.print("Enter the number of episodes: ");
                series.SeriesNumberOfEpisodes = scanner.nextLine();
                
                found = true;
                System.out.println("Series updated successfully!");
                break;
            }//Code guided by Artificial Inteligence
        }
        
        if (!found) {
            System.out.println("Series with Series Id: " + id + " was not found!");
        }
        
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String input = scanner.nextLine();
        if (input.equals("1")) {
            displayMenu();
        }//Code guided by Artificial Inteligence
    }
    
    // Method to delete a series
    public void DeleteSeries() {
        System.out.println("*******************************");
        System.out.print("Enter the series id to delete: ");
        System.out.println();
        System.out.println("*********************************");
        System.out.println();
        String id = scanner.nextLine();
        
        boolean found = false;//boolean, check if the user wants to delet yes/no 
        for (int i = 0; i < seriesList.size(); i++) {
            if (seriesList.get(i).SeriesId.equals(id)) {
                System.out.print("Are you sure you want to delete series " + id + " from the system? Yes (y) to delete: ");
                String confirmation = scanner.nextLine();//Code guided by Artificial Inteligence1
                
                if (confirmation.equalsIgnoreCase("y")) {
                    seriesList.remove(i);
                    System.out.println("----------------------------------");
                    System.out.println("Series with Series Id: " + id + " WAS deleted!");
                    System.out.println("--------------------------------");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                
                found = true;
                break;
            }//Code guided by Artificial Inteligence
        }
        
        if (!found) {
            System.out.println("Series with Series Id: " + id + " was not found!");
        }
        
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String input = scanner.nextLine();
        if (input.equals("1")) {
            displayMenu();
        }
    }//Code guided by Artificial Inteligence
    
    // Method to print the current series report
    public void SeriesReport() {
        System.out.println();
        for (int i = 0; i < seriesList.size(); i++) {
            SeriesModel series = seriesList.get(i);
            System.out.println("Series " + (i + 1));
            System.out.println("--- SERIES ID: " + series.SeriesId);
            System.out.println("SERIES NAME: " + series.SeriesName);
            System.out.println("SERIES AGE RESTRICTION: " + series.SeriesAge);
            System.out.println("NUMBER OF EPISODES: " + series.SeriesNumberOfEpisodes);
            System.out.println("----------------------------------------");
        }
        
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String input = scanner.nextLine();
        if (input.equals("1")) {
            displayMenu();
        }//Code guided by Artificial Inteligence
    }
    
    // Method to exit the application
    public void ExitSeriesApplication() {
        System.out.println("Exiting application. Goodbye!");
        scanner.close();
        System.exit(0);
    }
    
    // Helper method to check if a string is numeric
    private boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }//Code guided by Artificial Inteligence
    }
}