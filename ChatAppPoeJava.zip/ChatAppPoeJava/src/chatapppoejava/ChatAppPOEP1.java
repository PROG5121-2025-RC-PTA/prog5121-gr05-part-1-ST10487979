/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatapppoejava;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;

public class ChatAppPOEP1 {
    //this array is to store information for ten users
    static String[] userNames = new String[10];
    static String[] passWords = new String[10];
    static String[] phoneNumbers = new String[10];
    static int userCount = 2; // Starting at 2, assuming two pre-registered users
//code guide by Ai
   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Hello there and welcome to our Porsche ChatApp!");

        while (true) {
            System.out.println("Menu:");
            System.out.println();
            System.out.println("1. Register User");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option (1-3): ");

            String choice = input.nextLine();

            if (choice.equals("1")) {
                register(input);
            } else if (choice.equals("2")) {
                login(input);
            } else if (choice.equals("3")) {
                System.out.println("Exiting program. Thank you!");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
        input.close();
    }//code guided by Ai

    static void register(Scanner input) {
        if (userCount >= 10) {
            System.out.println("User limit reached! Cannot register more users.");
            return;
        }

        System.out.println("<<<Registration>>>");
        System.out.println();
        System.out.print("Please enter your username (max of 5 characters and must include _ ): ");
        String username = input.nextLine();

        if (username.length() > 5 || !username.contains("_")) {
            System.out.println("Invalid username, please make sure it's 5 characters or less and includes '_'.");
            return;
        }//code guide by Ai

        // method is to check if the input are duplicate usernames
        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(username)) {
                System.out.println("This username already exists! Please choose a different username.");
                return;
            }
        }

        System.out.print("PLease enter your password (minimum of 8 characters, with an uppercase, a number, and a symbol): ");
        String password = input.nextLine();

            // this method here eis to validate the user is password
        boolean hasUppercase = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSymbol = !password.matches("[A-Za-z0-9]*");

        if (password.length() < 8 || !hasUppercase || !hasNumber || !hasSymbol) {
            System.out.println("Invalid password! Must be at least 8 characters and include an uppercase letter, a number, and a symbol.");
            return;
        }//code guided by Ai

        System.out.print("Please enter your phone number (+27 followed by 9 digits): ");
        String phone = input.nextLine();

        if (phone.length() != 11 || !phone.startsWith("+27")) {
            System.out.println("Invalid phone number! Format should be like so: +27123456789.");
            return;
        }

        //this array is used to Store the users information
        userNames[userCount] = username;
        passWords[userCount] = password;
        phoneNumbers[userCount] = phone;
        userCount++;
        //code guided by ai

        System.out.println("your registration was successful!");
        System.out.println("Welcome to our PORSCHE APPLICATION");
        System.out.println("Username: " + username + " | Phone: " + phone);
    }

    //this method is promt the user to input cridentials(password and username)
    static void login(Scanner input) {
        System.out.println("<<<Login>>>");
        System.out.println();
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();

        boolean foundUser = false;
        boolean correctPassword = false;

        //this method is to check the user credentials
        for (int i = 0; i < userCount; i++) {
            if (userNames[i] != null && userNames[i].equals(username)) {
                foundUser = true;
                if (passWords[i].equals(password)) {
                    correctPassword = true;
                }
                break;// this we are breaking the loop
            }
        }//guided by Ai
        
// Check if the username exists in the database and the password matches.     
        if (foundUser && correctPassword) {
            System.out.println("Login successful!");
        } else if (!foundUser) {
            System.out.println("Username not found. Please register.");
        } else {
            System.out.println("Login failed. Incorrect password.");
        }// code guided by Ai(Claude)
    }
}
